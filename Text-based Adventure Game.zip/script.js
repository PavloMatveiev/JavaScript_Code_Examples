// Define the Game class with descriptions and options for each stage
class Game {
    constructor(description, options) {
        this.description = description; // Description of the current game stage
        this.options = options; // Available options at this stage
    }

    // Display the game's current stage on the webpage
    display() {
        const displayElement = document.getElementById('gameDisplay');
        displayElement.innerHTML = `<p>${this.description}</p>`;
        this.options.forEach((option, index) => {
            const button = document.createElement('button');
            button.textContent = `${index + 1}: ${option.text}`;
            button.onclick = () => {
                this.choose(index + 1)
                    .then(game => game.display());
            };
            displayElement.appendChild(button);
        });
    }

    // Handle choice selection and advance the game based on the option chosen
    choose(optionIndex) {
        const option = this.options[optionIndex - 1];
        if (option) {
            return option.action();
        }
        console.log("Invalid option. Try again.");
        return Promise.resolve(this); // Return current game stage if invalid option
    }
}

// Define the GameEngine class to manage game flow
class GameEngine {
    constructor() {
        this.currentGame = null;
    }

    // Start the game with the initial game stage
    start(game) {
        this.currentGame = game;
        this.currentGame.display();
    }
}

// Game setup with scenarios and options
const endGame = new Game("You have found the treasure. Congratulations!", []);

const fightDragon = new Game(
    "You are facing a dragon. What will you do?",
    [
        { text: "Fight", action: () => Promise.resolve(endGame) },
        { text: "Run", action: () => Promise.resolve(new Game("You ran away safely.", [])) }
    ]
);

const startGame = new Game(
    "You are at a fork in the road. Do you go left or right?",
    [
        { text: "Left", action: () => Promise.resolve(fightDragon) },
        { text: "Right", action: () => Promise.resolve(new Game("You walked into a swamp and sunk.", [])) }
    ]
);

// Initialize the game engine and start the game
const gameEngine = new GameEngine();
document.addEventListener('DOMContentLoaded', () => gameEngine.start(startGame));
