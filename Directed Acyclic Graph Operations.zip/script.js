class DirectedAcyclicGraph {
    constructor() {
        // Initialize an adjacency list to store the graph
        this.adjList = new Map();
    }

    // Add a new node to the graph with no edges
    addNode(node) {
        if (!this.adjList.has(node)) {
            this.adjList.set(node, []);
        }
    }

    // Add an edge from one node to another
    addEdge(from, to) {
        // Ensure both nodes exist in the graph before adding an edge
        if (!this.adjList.has(from) || !this.adjList.has(to)) {
            throw new Error("Both nodes must be added before creating an edge.");
        }
        // Check for potential cycles before adding the edge
        if (this._detectCycleUtil(new Set(), from, to)) {
            throw new Error("Adding this edge creates a cycle, which is not allowed in a DAG.");
        }
        this.adjList.get(from).push(to);
    }

    // Remove a node and all edges leading to or from it
    removeNode(node) {
        // Remove the node from the adjacency list
        this.adjList.delete(node);
        // Remove all edges pointing to this node
        for (let [key, value] of this.adjList) {
            const index = value.indexOf(node);
            if (index > -1) {
                value.splice(index, 1);
            }
        }
    }

    // Remove an edge from one node to another
    removeEdge(from, to) {
        const nodeEdges = this.adjList.get(from);
        if (nodeEdges) {
            const index = nodeEdges.indexOf(to);
            if (index > -1) {
                nodeEdges.splice(index, 1);
            }
        }
    }

    // Perform topological sort on the graph and return the ordered nodes
    topologicalSort() {
        const visited = new Set();
        const stack = [];
        const isBeingVisited = new Set();

        // Use DFS to find topological ordering
        for (let node of this.adjList.keys()) {
            if (!visited.has(node)) {
                if (!this._topologicalSortUtil(node, visited, stack, isBeingVisited)) {
                    throw new Error("This graph is not a DAG.");
                }
            }
        }
        return stack.reverse();
    }

    // Helper function for topological sorting
    _topologicalSortUtil(node, visited, stack, isBeingVisited) {
        visited.add(node);
        isBeingVisited.add(node);
        
        const neighbors = this.adjList.get(node);
        for (let neighbor of neighbors) {
            if (isBeingVisited.has(neighbor)) {
                return false; // Not a DAG if a cycle is detected
            }
            if (!visited.has(neighbor)) {
                if (!this._topologicalSortUtil(neighbor, visited, stack, isBeingVisited)) {
                    return false;
                }
            }
        }
        
        isBeingVisited.delete(node);
        stack.push(node);
        return true;
    }

    // Utility function to detect if adding a certain edge would create a cycle
    _detectCycleUtil(visited, current, target) {
        if (current === target) {
            return true; // Cycle detected
        }
        visited.add(current);

        const neighbors = this.adjList.get(current);
        for (let neighbor of neighbors) {
            if (!visited.has(neighbor) && this._detectCycleUtil(visited, neighbor, target)) {
                return true;
            }
        }
        visited.delete(current);
        return false;
    }
}

// Example Usage:
function testDAG() {
    const dag = new DirectedAcyclicGraph();
    dag.addNode("A");
    dag.addNode("B");
    dag.addNode("C");
    dag.addEdge("A", "B");
    dag.addEdge("B", "C");
    try {
        alert("Topological sort result: " + dag.topologicalSort());
    } catch (e) {
        alert(e.message);
    }
}
